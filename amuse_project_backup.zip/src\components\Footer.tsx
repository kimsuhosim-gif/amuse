﻿// file: src/components/Footer.tsx
import { Instagram, MapPin, Phone } from "lucide-react";

export default function Footer() {
  return (
    <footer className="bg-[#140f0c] px-6 pb-28 pt-20 text-white md:px-10 md:pb-16">
      <div className="mx-auto grid w-full max-w-7xl gap-10 rounded-2xl border border-[#6a4d39] bg-gradient-to-br from-[#2a1e17] via-[#1d1511] to-[#100c09] p-8 md:grid-cols-[1.3fr_1fr_1fr]">
        <div className="space-y-4">
          <p className="font-display text-4xl text-[#f5e7dc]">AMUSE.</p>
          <p className="text-[15px] leading-7 text-[#d4c2b6]">
            아뮤즈 폴댄스 · 플라잉요가
            <br />
            신림점 · 안양점 운영
          </p>
          <a href="https://www.instagram.com/amuse_aerial_studio/" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 text-sm text-[#f0d9c8] hover:text-white">
            <Instagram size={16} /> @amuse_aerial_studio
          </a>
        </div>

        <div className="space-y-3 text-[15px] text-[#d8c7bc]">
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#c8a88f]">신림점</p>
          <p className="inline-flex items-center gap-2"><MapPin size={15} /> 서울 관악구 신사로 116-1 3층</p>
          <p className="inline-flex items-center gap-2"><Phone size={15} /> 전화번호는 네이버지도 확인</p>
        </div>

        <div className="space-y-3 text-[15px] text-[#d8c7bc]">
          <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#c8a88f]">안양점</p>
          <p className="inline-flex items-center gap-2"><MapPin size={15} /> 경기 안양시 동안구 관악대로 103 9층</p>
          <p className="inline-flex items-center gap-2"><Phone size={15} /> 031-464-0101</p>
        </div>
      </div>

      <div className="mx-auto mt-6 flex w-full max-w-7xl flex-col gap-3 text-xs text-[#bfaea4] md:flex-row md:items-center md:justify-between">
        <p>Copyright 2026 AMUSE Aerial Studio. All rights reserved.</p>
        <div className="flex gap-6">
          <a href="#" className="transition-colors hover:text-white">개인정보처리방침</a>
          <a href="#" className="transition-colors hover:text-white">이용약관</a>
        </div>
      </div>
    </footer>
  );
}
