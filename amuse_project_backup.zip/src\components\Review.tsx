﻿// file: src/components/Review.tsx
import { Quote, Star } from "lucide-react";

const reviewStats = [
  { branch: "안양점", visit: 377, blog: 100, note: "네이버 지도 기준" },
  { branch: "신림점", visit: 40, blog: 37, note: "네이버 지도 기준" },
];

const reviewSamples = [
  {
    name: "신림점 체험",
    text: "첫 수업인데도 설명이 정확해서 동작을 금방 이해했고, 공간 분위기도 정말 좋았어요.",
  },
  {
    name: "안양점 회원",
    text: "수업 후 몸이 가벼워지는 느낌이 좋고, 강사 피드백이 디테일해서 만족도가 높습니다.",
  },
  {
    name: "재등록 회원",
    text: "체형 교정과 코어 강화가 눈에 보여서 꾸준히 다니게 됩니다.",
  },
];

export default function Review() {
  return (
    <section id="review" className="section-shell bg-[#eadfd3] py-24 md:py-32">
      <div className="mx-auto w-full max-w-7xl px-6 md:px-10">
        <div className="mb-10 flex flex-col gap-4 md:flex-row md:items-end md:justify-between">
          <div className="space-y-4">
            <p className="kicker">REVIEW</p>
            <h2 className="title-tight text-4xl text-[#1b1513] md:text-6xl">지점별 리뷰 반응</h2>
          </div>
          <p className="max-w-md text-sm leading-7 text-[#64554b]">
            방문자 리뷰와 블로그 리뷰를 함께 확인하고,
            실제 체험 후기 기반으로 지점을 선택해 보세요.
          </p>
        </div>

        <div className="mb-4 grid gap-4 md:grid-cols-2">
          {reviewStats.map((stat) => (
            <article key={stat.branch} className="frame-strong rounded-2xl p-6">
              <p className="text-xs uppercase tracking-[0.14em] text-[#7a675a]">{stat.note}</p>
              <h3 className="mt-2 text-2xl font-semibold text-[#1a1410]">{stat.branch}</h3>
              <div className="mt-3 flex gap-6 text-sm text-[#574940]">
                <p>방문자 리뷰 <strong className="text-[#2c1f17]">{stat.visit}</strong></p>
                <p>블로그 리뷰 <strong className="text-[#2c1f17]">{stat.blog}</strong></p>
              </div>
            </article>
          ))}
        </div>

        <div className="grid gap-4 md:grid-cols-3">
          {reviewSamples.map((review) => (
            <article key={review.name} className="frame rounded-2xl p-7">
              <div className="flex items-center justify-between">
                <p className="text-xs font-semibold uppercase tracking-[0.14em] text-[#6c5c52]">회원 후기</p>
                {review.name.includes("안양") ? <Star size={14} className="text-[#7b6658]" /> : <Quote size={15} className="text-[#7b6658]" />}
              </div>
              <h3 className="mt-2 text-lg font-semibold text-[#1a1410]">{review.name}</h3>
              <p className="mt-4 text-[15px] leading-8 text-[#66574d]">{review.text}</p>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
