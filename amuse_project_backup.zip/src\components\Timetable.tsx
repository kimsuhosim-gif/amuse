﻿"use client";

// file: src/components/Timetable.tsx
import { useMemo, useState } from "react";
import { CalendarClock, Clock3, ExternalLink, MapPin, Phone } from "lucide-react";

type BranchId = "sinrim" | "anyang";
type ClassItem = { time: string; name: string; level: string };

const timetableData: Record<BranchId, ClassItem[]> = {
  sinrim: [
    { time: "10:30", name: "입문 플라잉요가", level: "Beginner" },
    { time: "13:00", name: "기초 폴댄스", level: "Beginner" },
    { time: "19:00", name: "폴 플로우", level: "All Level" },
    { time: "20:30", name: "코어 강화 플라잉", level: "All Level" },
  ],
  anyang: [
    { time: "11:00", name: "입문 폴댄스", level: "Beginner" },
    { time: "14:30", name: "유연성 플라잉요가", level: "All Level" },
    { time: "18:30", name: "힐 폴댄스", level: "Intermediate" },
    { time: "20:00", name: "아트 플로우", level: "Intermediate" },
  ],
};

const branchInfo = {
  sinrim: {
    label: "신림점",
    address: "서울 관악구 신사로 116-1 3층",
    access: "신대방역 1번 출구 도보권",
    phone: "전화번호는 네이버지도에서 확인",
    mapUrl:
      "https://map.naver.com/p/search/%EC%95%84%EB%AE%A4%EC%A6%88%ED%8F%B4%EB%8C%84%EC%8A%A4%20%EC%8B%A0%EB%A6%BC%EC%A0%90",
  },
  anyang: {
    label: "안양점",
    address: "경기 안양시 동안구 관악대로 103 9층",
    access: "비산동 사거리 인근",
    phone: "031-464-0101",
    mapUrl:
      "https://map.naver.com/p/search/%EC%95%84%EB%AE%A4%EC%A6%88%ED%8F%B4%EB%8C%84%EC%8A%A4%20%EC%95%88%EC%96%91%EC%A0%90",
  },
} as const;

const branchLabels: Record<BranchId, string> = { sinrim: "신림점", anyang: "안양점" };

export default function Timetable() {
  const [activeBranch, setActiveBranch] = useState<BranchId>("sinrim");
  const activeSchedule = useMemo(() => timetableData[activeBranch], [activeBranch]);
  const info = branchInfo[activeBranch];

  return (
    <section id="timetable" className="section-shell dark-band py-24 text-white md:py-32">
      <div className="mx-auto w-full max-w-6xl px-6 md:px-10">
        <div className="mb-10 space-y-4 text-center">
          <p className="kicker-invert">CLASS & LOCATION</p>
          <h2 className="title-tight text-4xl text-white md:text-6xl">지점별 시간표와 위치 안내</h2>
          <p className="mx-auto max-w-lg text-sm leading-7 text-[#cdb6a6]">
            원하는 지점을 선택하면 시간표와 방문 정보를 함께 확인할 수 있습니다.
          </p>
        </div>

        <div className="mx-auto mb-5 flex max-w-sm gap-2 rounded-xl border border-white/20 bg-white/[0.03] p-1.5">
          {(Object.keys(branchLabels) as BranchId[]).map((branch) => (
            <button
              key={branch}
              type="button"
              onClick={() => setActiveBranch(branch)}
              className={`flex-1 rounded-lg px-4 py-2.5 text-sm font-semibold transition-all ${
                activeBranch === branch
                  ? "bg-white text-[#1a130f] shadow-[0_10px_28px_-18px_rgba(255,255,255,0.75)]"
                  : "text-zinc-300 hover:bg-white/10"
              }`}
            >
              {branchLabels[branch]}
            </button>
          ))}
        </div>

        <div className="mb-5 grid gap-4 md:grid-cols-3">
          <article className="rounded-xl border border-white/20 bg-white/[0.06] p-4">
            <p className="text-xs uppercase tracking-[0.14em] text-[#d7bca6]">주소</p>
            <p className="mt-2 inline-flex items-center gap-2 text-sm text-white"><MapPin size={15} /> {info.address}</p>
          </article>
          <article className="rounded-xl border border-white/20 bg-white/[0.06] p-4">
            <p className="text-xs uppercase tracking-[0.14em] text-[#d7bca6]">접근</p>
            <p className="mt-2 text-sm text-white">{info.access}</p>
          </article>
          <article className="rounded-xl border border-white/20 bg-white/[0.06] p-4">
            <p className="text-xs uppercase tracking-[0.14em] text-[#d7bca6]">문의</p>
            <p className="mt-2 inline-flex items-center gap-2 text-sm text-white"><Phone size={14} /> {info.phone}</p>
          </article>
        </div>

        <div className="electric-border">
          <div className="electric-content overflow-hidden rounded-[1.25rem] border border-white/20 bg-black/45 backdrop-blur-sm">
            {activeSchedule.map((item) => (
              <div
                key={`${activeBranch}-${item.time}-${item.name}`}
                className="grid grid-cols-[90px_1fr] gap-4 border-b border-white/10 px-5 py-5 last:border-b-0 md:grid-cols-[120px_1fr_auto] md:px-8"
              >
                <p className="title-tight flex items-center gap-1 text-3xl text-white">
                  <Clock3 size={18} className="text-[#e7c9ad]" />
                  {item.time}
                </p>
                <div>
                  <p className="text-[15px] font-semibold text-white md:text-[17px]">{item.name}</p>
                  <p className="mt-1 text-xs text-zinc-400">{item.level}</p>
                </div>
                <a
                  href="https://booking.naver.com"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="cta-outline-invert mt-2 w-fit gap-1.5 px-4 py-2 text-[11px] md:mt-0"
                >
                  <CalendarClock size={14} /> 예약
                </a>
              </div>
            ))}
          </div>
        </div>

        <div className="mt-5 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <a href={info.mapUrl} target="_blank" rel="noopener noreferrer" className="cta-outline-invert gap-1.5">
            <ExternalLink size={14} /> 네이버지도에서 {info.label} 보기
          </a>
          <a href="https://booking.naver.com" target="_blank" rel="noopener noreferrer" className="cta-primary">
            네이버 예약 바로가기
          </a>
        </div>
      </div>
    </section>
  );
}
