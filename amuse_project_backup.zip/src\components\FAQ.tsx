﻿"use client";

// file: src/components/FAQ.tsx
import { useState } from "react";
import { Plus } from "lucide-react";

const faqItems = [
  {
    question: "정말 초보자도 가능한가요?",
    answer:
      "가능합니다. 체험 수업은 기초 자세와 안전 수칙부터 시작해 개인별 난이도로 안내합니다.",
  },
  {
    question: "체험 수업 준비물은 무엇인가요?",
    answer:
      "편한 운동복과 물만 준비해 주세요. 필요한 기본 안내는 현장에서 모두 제공됩니다.",
  },
  {
    question: "예약은 어디서 하나요?",
    answer:
      "네이버 예약 또는 카카오톡 채널 상담으로 원하는 지점/시간을 선택할 수 있습니다.",
  },
  {
    question: "신림/안양 지점은 어떻게 선택하나요?",
    answer:
      "이동 동선과 목표를 알려주시면 카카오톡 상담에서 가장 적합한 클래스를 추천해드립니다.",
  },
  {
    question: "커플/키즈/자격증·강사양성반도 가능한가요?",
    answer:
      "가능합니다. 운영 일정은 지점별로 다를 수 있어 네이버 예약 또는 카카오 상담에서 현재 가능한 반을 안내드립니다.",
  },
];

export default function FAQ() {
  const [openIndex, setOpenIndex] = useState(0);

  return (
    <section id="faq" className="section-shell bg-[#f5ebe1] py-24 md:py-32">
      <div className="mx-auto w-full max-w-4xl px-6 md:px-10">
        <div className="mb-10 space-y-4 text-center">
          <p className="kicker">FAQ</p>
          <h2 className="title-tight text-4xl text-[#1b1513] md:text-6xl">Before Your First Class</h2>
        </div>

        <div className="frame-strong overflow-hidden rounded-2xl">
          {faqItems.map((item, index) => {
            const open = index === openIndex;
            return (
              <article key={item.question} className="border-b border-[#cfbcb0] last:border-b-0">
                <button
                  type="button"
                  onClick={() => setOpenIndex(open ? -1 : index)}
                  className="flex w-full items-center justify-between px-5 py-5 text-left md:px-8"
                >
                  <span className="text-[15px] font-semibold text-[#2a201d] md:text-[17px]">{item.question}</span>
                  <span className={`ml-4 transition-transform ${open ? "rotate-45" : "rotate-0"}`}>
                    <Plus size={16} className="text-[#6e5e54]" />
                  </span>
                </button>
                {open && (
                  <p className="px-5 pb-6 text-[15px] leading-8 text-[#6b5e58] md:px-8">{item.answer}</p>
                )}
              </article>
            );
          })}
        </div>

        <div className="mt-8 flex flex-col gap-3 sm:flex-row sm:justify-center">
          <a href="https://booking.naver.com" target="_blank" rel="noopener noreferrer" className="cta-primary">
            네이버 예약
          </a>
          <a href="https://pf.kakao.com" target="_blank" rel="noopener noreferrer" className="cta-outline">
            카카오 상담
          </a>
        </div>
      </div>
    </section>
  );
}
