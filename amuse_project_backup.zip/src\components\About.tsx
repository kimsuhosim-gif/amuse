﻿// file: src/components/About.tsx
import Image from "next/image";
import { ArrowUpRight, CalendarCheck, Dumbbell, GraduationCap, Users } from "lucide-react";

export default function About() {
  return (
    <section id="about" className="section-shell bg-[#efebe6] py-22 md:py-28">
      <div className="mx-auto w-full max-w-7xl px-6 md:px-10">
        <div className="mb-10 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
          <div>
            <p className="kicker">ABOUT AMUSE</p>
            <h2 className="title-tight text-[2.05rem] text-[#1e1b18] md:text-[3.2rem]">등록 전에 필요한 정보를 먼저 보여줍니다</h2>
          </div>
          <p className="max-w-md text-sm leading-7 text-[#66615c]">
            지점, 수업 구성, 대상, 예약 방식까지 한 화면에서 바로 확인할 수 있게 구성했습니다.
          </p>
        </div>

        <div className="grid gap-4 md:grid-cols-[1.55fr_1.1fr_0.9fr] md:grid-rows-[280px_280px]">
          <article className="bento-card relative overflow-hidden p-6 md:row-span-2">
            <p className="kicker">MAIN STUDIO</p>
            <h3 className="mt-2 text-[1.9rem] font-semibold leading-tight text-[#25221f]">밝고 깔끔한 화이트톤 공간</h3>
            <p className="mt-3 max-w-md text-sm leading-7 text-[#5f5952]">
              첫 방문도 부담 없이 시작할 수 있게 조도와 동선, 시야감을 정돈했습니다.
            </p>
            <div className="mt-5 overflow-hidden rounded-2xl border border-[#ddd4ca]">
              <div className="relative aspect-[4/3]">
                <Image
                  src="https://images.unsplash.com/photo-1534258936925-c58bed479fcb?q=80&w=1500&auto=format&fit=crop"
                  alt="화이트톤 스튜디오 공간"
                  fill
                  className="object-cover"
                  sizes="(max-width: 768px) 100vw, 44vw"
                />
              </div>
            </div>
          </article>

          <article className="frame-strong p-6">
            <p className="kicker">CLASS FLOW</p>
            <h3 className="mt-2 text-3xl font-semibold leading-tight text-[#22201d]">초보자부터 단계별 성장</h3>
            <p className="mt-3 text-sm leading-7 text-[#666059]">체험반 · 기초반 · 응용반 흐름으로 목표에 맞게 연결됩니다.</p>
          </article>

          <article className="relative overflow-hidden rounded-3xl border border-[#d8cec3] bg-[#181513] p-6 text-white md:row-span-2">
            <div className="absolute inset-0 opacity-50">
              <Image
                src="https://images.unsplash.com/photo-1518611012118-29a883a4817a?q=80&w=1200&auto=format&fit=crop"
                alt="아뮤즈 스튜디오 무드"
                fill
                className="object-cover"
                sizes="(max-width: 768px) 100vw, 24vw"
              />
            </div>
            <div className="relative z-10 flex h-full flex-col justify-between">
              <div>
                <p className="text-[11px] uppercase tracking-[0.14em] text-white/74">2 BRANCH</p>
                <p className="mt-2 text-[2.1rem] font-semibold leading-[1.05]">신림점<br />안양점</p>
                <p className="mt-3 text-sm text-white/85">지점별 시간표와 위치 정보 바로 확인</p>
              </div>
              <a href="#timetable" className="inline-flex w-fit items-center gap-1 rounded-full bg-white px-4 py-2 text-xs font-semibold text-[#1b1815]">
                위치 보기 <ArrowUpRight size={13} />
              </a>
            </div>
          </article>

          <div className="grid grid-cols-2 gap-4">
            <article className="frame rounded-2xl p-5">
              <div className="inline-flex rounded-lg border border-[#ddd3c8] bg-[#fbfaf8] p-2.5 text-[#4f453d]">
                <Dumbbell size={18} />
              </div>
              <h3 className="mt-3 text-base font-semibold text-[#24201c]">프로그램</h3>
              <p className="mt-2 text-sm leading-6 text-[#666059]">폴댄스 · 플라잉요가</p>
            </article>
            <article className="frame rounded-2xl p-5">
              <div className="inline-flex rounded-lg border border-[#ddd3c8] bg-[#fbfaf8] p-2.5 text-[#4f453d]">
                <Users size={18} />
              </div>
              <h3 className="mt-3 text-base font-semibold text-[#24201c]">수강 대상</h3>
              <p className="mt-2 text-sm leading-6 text-[#666059]">초보자 · 취미반 · 커플/키즈</p>
            </article>
            <article className="frame rounded-2xl p-5">
              <div className="inline-flex rounded-lg border border-[#ddd3c8] bg-[#fbfaf8] p-2.5 text-[#4f453d]">
                <GraduationCap size={18} />
              </div>
              <h3 className="mt-3 text-base font-semibold text-[#24201c]">확장 과정</h3>
              <p className="mt-2 text-sm leading-6 text-[#666059]">자격증반 · 강사양성반</p>
            </article>
            <article className="frame rounded-2xl p-5">
              <div className="inline-flex rounded-lg border border-[#ddd3c8] bg-[#fbfaf8] p-2.5 text-[#4f453d]">
                <CalendarCheck size={18} />
              </div>
              <h3 className="mt-3 text-base font-semibold text-[#24201c]">예약 방식</h3>
              <p className="mt-2 text-sm leading-6 text-[#666059]">네이버 예약 · 카카오 상담</p>
            </article>
          </div>
        </div>
      </div>
    </section>
  );
}
