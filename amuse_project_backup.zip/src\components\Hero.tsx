﻿// file: src/components/Hero.tsx
import Image from "next/image";
import { ArrowUpRight, MapPin, MoveRight } from "lucide-react";

const stats = [
  { label: "운영 시작", value: "Since 2022" },
  { label: "Instagram", value: "@amuse_aerial_studio" },
  { label: "프로그램", value: "폴댄스 · 플라잉요가" },
];

export default function Hero() {
  return (
    <section className="section-shell relative pt-28 md:pt-32" aria-label="메인 소개">
      <div className="mx-auto grid w-full max-w-7xl gap-8 px-6 pb-18 md:grid-cols-[1.05fr_0.95fr] md:items-center md:px-10 md:pb-24">
        <div className="space-y-7">
          <p className="kicker">AMUSE POLE & FLYING YOGA</p>
          <h1 className="title-tight text-[2.1rem] text-[#1c1a18] md:text-[3.8rem]">
            초보자도 시작하기 쉬운
            <br />
            아뮤즈 체험 클래스
          </h1>
          <p className="max-w-xl text-[15px] leading-8 text-[#5f5953] md:text-[17px]">
            신림점·안양점에서 폴댄스와 플라잉요가를 초보자 기준으로 안내합니다.
            체험 수업부터 정규반까지 현재 컨디션에 맞춰 선택할 수 있습니다.
          </p>

          <div className="flex flex-col gap-3 sm:flex-row">
            <a
              href="https://booking.naver.com"
              target="_blank"
              rel="noopener noreferrer"
              className="cta-primary gap-1"
              aria-label="네이버 예약"
            >
              체험 예약하기 <MoveRight size={15} />
            </a>
            <a
              href="https://pf.kakao.com"
              target="_blank"
              rel="noopener noreferrer"
              className="cta-outline gap-1"
              aria-label="카카오 상담"
            >
              카카오 상담 <ArrowUpRight size={15} />
            </a>
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            {stats.map((stat) => (
              <article key={stat.label} className="frame min-w-0 rounded-xl p-4">
                <p className="text-[11px] uppercase tracking-[0.13em] text-[#7a7168]">{stat.label}</p>
                <p className={`mt-1 font-semibold text-[#24211e] ${stat.label === "Instagram" ? "break-all text-[15px]" : "text-base"}`}>
                  {stat.value}
                </p>
              </article>
            ))}
          </div>
        </div>

        <article className="frame-strong overflow-hidden rounded-[1.5rem]">
          <div className="relative aspect-[4/5]">
            <Image
              src="https://images.unsplash.com/photo-1571019614242-c5c5dee9f50b?q=80&w=1800&auto=format&fit=crop"
              alt="아뮤즈 수업 무드"
              fill
              priority
              className="object-cover"
              sizes="(max-width: 768px) 100vw, 42vw"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/62 via-black/10 to-transparent" />
            <div className="absolute bottom-0 left-0 right-0 p-5 text-white md:p-6">
              <p className="inline-flex items-center gap-1 text-[11px] uppercase tracking-[0.13em] text-white/78">
                <MapPin size={12} /> 신림점 · 안양점
              </p>
              <h2 className="mt-2 font-display text-3xl leading-tight md:text-4xl">Start at Your Pace</h2>
              <p className="mt-2 text-sm text-white/78">체험부터 취미반, 단계별 프로그램 운영</p>
            </div>
          </div>
        </article>
      </div>
    </section>
  );
}
