﻿import Navbar from "@/components/Navbar";
import Hero from "@/components/Hero";
import About from "@/components/About";
import Timetable from "@/components/Timetable";
import Review from "@/components/Review";
import FAQ from "@/components/FAQ";
import Footer from "@/components/Footer";

export default function Home() {
  return (
    <main className="min-h-screen bg-transparent">
      <Navbar />
      <Hero />
      <About />
      <Timetable />
      <Review />
      <FAQ />
      <Footer />

      <div className="fixed inset-x-0 bottom-0 z-50 border-t border-[#d8c5ba] bg-[#fff8f3]/95 px-4 py-3 backdrop-blur md:hidden">
        <div className="mx-auto flex max-w-md gap-2">
          <a
            href="https://booking.naver.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="네이버 예약으로 이동"
            className="cta-primary flex-1 px-4 py-3 text-[11px]"
          >
            네이버 예약
          </a>
          <a
            href="https://pf.kakao.com"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="카카오톡 채널 상담으로 이동"
            className="cta-outline flex-1 px-4 py-3 text-[11px]"
          >
            카카오 상담
          </a>
        </div>
      </div>
    </main>
  );
}
