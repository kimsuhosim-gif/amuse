﻿"use client";

// file: src/components/Navbar.tsx
import Link from "next/link";
import { useEffect, useState } from "react";

const navItems = [
  { label: "소개", href: "#about" },
  { label: "시간표", href: "#timetable" },
  { label: "후기", href: "#review" },
  { label: "FAQ", href: "#faq" },
];

export default function Navbar() {
  const [isScrolled, setIsScrolled] = useState(false);

  useEffect(() => {
    const onScroll = () => setIsScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener("scroll", onScroll);
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 px-4 py-4 transition-all md:px-10 ${
        isScrolled
          ? "glass-nav shadow-[0_14px_42px_-28px_rgba(49,30,14,0.58)]"
          : "bg-transparent"
      }`}
    >
      <nav className="mx-auto flex w-full max-w-7xl items-center justify-between rounded-2xl border border-[#d7c4b5]/65 bg-[#fffbf6]/80 px-4 py-3 backdrop-blur md:px-6">
        <Link href="/" className="font-display text-2xl text-[#1f1713] md:text-3xl">
          AMUSE.
        </Link>

        <div className="hidden items-center gap-7 text-sm font-medium text-[#655449] md:flex">
          {navItems.map((item) => (
            <Link
              key={item.href}
              href={item.href}
              className="transition-colors hover:text-[#291d16]"
            >
              {item.label}
            </Link>
          ))}
        </div>

        <a
          href="https://booking.naver.com"
          target="_blank"
          rel="noopener noreferrer"
          className="cta-outline px-4 py-2 text-[11px]"
        >
          체험 예약
        </a>
      </nav>
    </header>
  );
}
